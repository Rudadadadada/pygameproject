import os
import pygame

screen = pygame.display.set_mode((773, 450))
clock = pygame.time.Clock()
seva_left = True
seva_right = False
seva_stay = True
seva_sit = False
seva_jump = False
seva_side = -1
seva_jump_count = 10
seva_count_of_animation = 0
seva_x, seva_y = 600, 300
seva_fireball_x, seva_fireball_y = seva_x, seva_y


class FireBall:
    def __init__(self, seva_fireball_x, seva_fireball_y, seva_side, seva_count_of_animation):
        self.x = seva_fireball_x
        self.y = seva_fireball_y
        self.speed = 5 * seva_side
        self.seva_count_of_animation = seva_count_of_animation

    def fire(self):
        if seva_side == 1:
            screen.blit(fireballRight[(self.seva_count_of_animation // 3) % 8], (seva_fireball_x, seva_fireball_y))
            self.seva_count_of_animation += 1
        else:
            screen.blit(fireballLeft[(self.seva_count_of_animation // 3) % 8], (seva_fireball_x, seva_fireball_y))
            self.seva_count_of_animation += 1


def load_image(name, colorkey=None):
    fullname = os.path.join('pictures', name)
    image = pygame.image.load(fullname)
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


sevaGoRight = [pygame.image.load(f'pictures\\seva\\sevarun\\right\\srr{str(i)}.png') for i in range(1, 11)]

sevaGoLeft = [pygame.image.load(f'pictures\\seva\\sevarun\\left\\srl{str(i)}.png') for i in range(1, 11)]

sevaStayRight = [pygame.image.load(f'pictures\\seva\\sevastay\\right\\ssr{str(i)}.png') for i in range(1, 6)]

sevaStayLeft = [pygame.image.load(f'pictures\\seva\\sevastay\\left\\ssl{str(i)}.png') for i in range(1, 6)]

sevaSitRight = [pygame.image.load(f'pictures\\seva\\sevasit\\right\\ssitr{str(i)}.png') for i in range(1, 5)]

sevaSitLeft = [pygame.image.load(f'pictures\\seva\\sevasit\\left\\ssitl{str(i)}.png') for i in range(1, 5)]

sevaJumpRight = [pygame.image.load(f'pictures\\seva\\sevajump\\right\\sjr{str(i)}.png') for i in range(1, 8)]

sevaJumpLeft = [pygame.image.load(f'pictures\\seva\\sevajump\\left\\sjl{str(i)}.png') for i in range(1, 8)]

fireballRight = [pygame.image.load(f'pictures\\fireball\\right\\fr{str(i)}.png') for i in range(1, 9)]

fireballLeft = [pygame.image.load(f'pictures\\fireball\\left\\fl{str(i)}.png') for i in range(1, 9)]


all_sprites = pygame.sprite.Group()
sprite = pygame.sprite.Sprite()
sprite.image = load_image("fon.png")
sprite.rect = sprite.image.get_rect()
all_sprites.add(sprite)
sprite.rect.x = 0
sprite.rect.y = 0
fireballs = []

running = True


def draw():
    global seva_count_of_animation
    all_sprites.draw(screen)
    all_sprites.update()
    if seva_count_of_animation + 1 >= 60:
        seva_count_of_animation = 0

    if seva_left and seva_stay:
        screen.blit(sevaStayLeft[(seva_count_of_animation // 3) % 5], (seva_x, seva_y))
        seva_count_of_animation += 1
    elif seva_right and seva_stay:
        screen.blit(sevaStayRight[(seva_count_of_animation // 3) % 5], (seva_x, seva_y))
        seva_count_of_animation += 1
    else:
        if seva_left and not seva_stay and not seva_sit and not seva_jump:
            screen.blit(sevaGoLeft[(seva_count_of_animation // 3) % 10], (seva_x, seva_y))
            seva_count_of_animation += 1
        elif seva_right and not seva_stay and not seva_sit and not seva_jump:
            screen.blit(sevaGoRight[(seva_count_of_animation // 3) % 10], (seva_x, seva_y))
            seva_count_of_animation += 1
        elif seva_left and not seva_stay and seva_sit and not seva_jump:
            screen.blit(sevaSitLeft[(seva_count_of_animation // 3) % 4], (seva_x, seva_y))
            seva_count_of_animation += 1
        elif seva_right and not seva_stay and seva_sit and not seva_jump:
            screen.blit(sevaSitRight[(seva_count_of_animation // 3) % 4], (seva_x, seva_y))
            seva_count_of_animation += 1
        elif seva_right and not seva_stay and not seva_sit and seva_jump:
            screen.blit(sevaJumpRight[(seva_count_of_animation // 3) % 7], (seva_x, seva_y))
            seva_count_of_animation += 1
        elif seva_left and not seva_stay and not seva_sit and seva_jump:
            screen.blit(sevaJumpLeft[(seva_count_of_animation // 3) % 7], (seva_x, seva_y))
            seva_count_of_animation += 1
    for fireball in fireballs:
        fireball.fire()


step = 4
while running:
    for event in pygame.event.get():
        keys = pygame.key.get_pressed()
        if event.type == pygame.QUIT:
            running = False
    for fireball in fireballs:
        if 773 > fireball.x > 0:
            fireball.x += fireball.speed
            seva_fireball_x += fireball.speed
        else:
            fireballs.pop(fireballs.index(fireball))
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RCTRL]:
        if len(fireballs) < 2:
            if seva_right:
                seva_side = 1
                seva_fireball_x = seva_x + 20
                if seva_sit:
                    seva_fireball_y = seva_y - 20
                elif seva_jump:
                    seva_fireball_y = seva_y
                else:
                    seva_fireball_y = seva_y - 35
            else:
                seva_side = -1
                seva_fireball_x = seva_x - 20
                if seva_sit:
                    seva_fireball_y = seva_y - 20
                elif seva_jump:
                    seva_fireball_y = seva_y
                else:
                    seva_fireball_y = seva_y - 35
            fireballs.append(FireBall(seva_fireball_x, seva_fireball_y, seva_side, seva_count_of_animation))
        all_sprites.update()
    if keys[pygame.K_LEFT]:
        seva_y = 300
        seva_jump_count = 10
        seva_stay = False
        seva_left = True
        seva_right = False
        seva_jump = False
        if seva_x >= 0:
            if not seva_jump and not seva_sit:
                seva_x -= step
            elif not seva_jump and seva_sit:
                seva_x -= 1
    elif keys[pygame.K_RIGHT]:
        seva_y = 300
        seva_jump_count = 10
        seva_stay = False
        seva_left = False
        seva_right = True
        seva_jump = False
        if seva_x <= 773 - 40:
            if not seva_jump and not seva_sit:
                seva_x += step
            elif not seva_jump and seva_sit:
                seva_x += 1
    elif keys[pygame.K_DOWN]:
        seva_stay = False
        seva_jump = False
        seva_sit = True
        if seva_left:
            seva_left = True
            seva_right = False
        elif seva_right:
            seva_left = False
            seva_right = True
    elif keys[pygame.K_UP]:
        seva_stay = False
        seva_jump = True
        seva_sit = False
        if seva_left:
            seva_left = True
            seva_right = False
        elif seva_right:
            seva_left = False
            seva_right = True
        if seva_jump_count >= -10:
            if seva_jump_count < 0:
                seva_y += (seva_jump_count ** 2) / 2
            else:
                seva_y -= (seva_jump_count ** 2) / 2
            seva_jump_count -= 2
        else:
            seva_jump_count = 10
    else:
        seva_jump_count = 10
        seva_y = 300
        seva_stay = True
        seva_jump = False
        seva_sit = False
        if seva_left:
            seva_right = False
            seva_left = True
        elif seva_right:
            seva_right = True
            seva_left = False
    draw()
    pygame.display.flip()
    clock.tick(60)
pygame.quit()