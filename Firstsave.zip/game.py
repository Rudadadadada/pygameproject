import os
import pygame

screen = pygame.display.set_mode((773, 477))
clock = pygame.time.Clock()
seva_left = True
seva_right = False
seva_stay = True
seva_count_of_animation = 0
seva_x, seva_y = 600, 270


def load_image(name, colorkey=None):
    fullname = os.path.join('pictures', name)
    image = pygame.image.load(fullname)
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


sevaGoRight = [pygame.image.load('pictures\\sevarun\\right\\srr1.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr2.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr3.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr4.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr5.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr6.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr7.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr8.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr9.png'),
               pygame.image.load('pictures\\sevarun\\right\\srr10.png')]

sevaGoLeft = [pygame.image.load('pictures\\sevarun\\left\\srl1.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl2.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl3.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl4.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl5.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl6.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl7.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl8.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl9.png'),
               pygame.image.load('pictures\\sevarun\\left\\srl10.png')]

sevaStayRight = [pygame.image.load('pictures\\sevastay\\right\\ssr1.png'),
                 pygame.image.load('pictures\\sevastay\\right\\ssr2.png'),
                 pygame.image.load('pictures\\sevastay\\right\\ssr3.png'),
                 pygame.image.load('pictures\\sevastay\\right\\ssr4.png'),
                 pygame.image.load('pictures\\sevastay\\right\\ssr5.png')]

sevaStayLeft = [pygame.image.load('pictures\\sevastay\\left\\ssl1.png'),
                 pygame.image.load('pictures\\sevastay\\left\\ssl2.png'),
                 pygame.image.load('pictures\\sevastay\\left\\ssl3.png'),
                 pygame.image.load('pictures\\sevastay\\left\\ssl4.png'),
                 pygame.image.load('pictures\\sevastay\\left\\ssl5.png')]


all_sprites = pygame.sprite.Group()
sprite = pygame.sprite.Sprite()
sprite.image = load_image("fon.png")
sprite.rect = sprite.image.get_rect()
all_sprites.add(sprite)
sprite.rect.x = 0
sprite.rect.y = 0

running = True


def draw():
    global seva_count_of_animation
    all_sprites.draw(screen)
    all_sprites.update()
    if seva_count_of_animation + 1 >= 60:
        seva_count_of_animation = 0

    if seva_left and not seva_stay:
        screen.blit(sevaGoLeft[(seva_count_of_animation // 3) % 10], (seva_x, seva_y))
        seva_count_of_animation += 1
    elif seva_right and not seva_stay:
        screen.blit(sevaGoRight[(seva_count_of_animation // 3) % 10], (seva_x, seva_y))
        seva_count_of_animation += 1
    if seva_left and seva_stay:
        screen.blit(sevaStayLeft[(seva_count_of_animation // 3) % 5], (seva_x, seva_y))
        seva_count_of_animation += 1
    elif seva_right and seva_stay:
        screen.blit(sevaStayRight[(seva_count_of_animation // 3) % 5], (seva_x, seva_y))
        seva_count_of_animation += 1


step = 5
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        seva_stay = False
        seva_left = True
        seva_right = False
        seva_x -= step
    elif keys[pygame.K_RIGHT]:
        seva_stay = False
        seva_left = False
        seva_right = True
        seva_x += step
    else:
        if seva_left:
            seva_stay = True
            seva_right = False
            seva_left = True
        elif seva_right:
            seva_stay = True
            seva_right = True
            seva_left = False
    draw()
    pygame.display.flip()
    clock.tick(60)
pygame.quit()